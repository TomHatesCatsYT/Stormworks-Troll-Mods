This mod was developed by TomHatesCatsYT/Not Tom.
DO NOT REUPLOAD THIS WITHOUT PERMISSION!!

The buzzer can be heard all over the Stormworks map, even the moon!